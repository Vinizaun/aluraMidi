function tocaSom (idElementoAudio) {
    document.querySelector(idElementoAudio).play();

}

//para